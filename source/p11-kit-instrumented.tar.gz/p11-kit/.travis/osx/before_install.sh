brew update
brew install libffi

export PATH=${PATH}:/usr/local/opt/gettext/bin
export PKG_CONFIG_PATH=${PKG_CONFIG_PATH}:/usr/local/opt/libffi/lib/pkgconfig

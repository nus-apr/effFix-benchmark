#!/bin/sh

cat test-suite.log

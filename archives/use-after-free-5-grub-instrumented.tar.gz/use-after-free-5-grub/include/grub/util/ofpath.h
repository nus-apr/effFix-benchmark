#ifndef GRUB_OFPATH_MACHINE_UTIL_HEADER
#define GRUB_OFPATH_MACHINE_UTIL_HEADER	1

char *grub_util_devname_to_ofpath (const char *devname);

#endif /* ! GRUB_OFPATH_MACHINE_UTIL_HEADER */

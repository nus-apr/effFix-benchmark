#include <grub/i386/coreboot/kernel.h>

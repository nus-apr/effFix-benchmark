Developer files
===============

Here are all kinds of things that an OpenSSL developer might need or
might choose to use.  Some of them demand access to OpenSSL's
infrastructure, others are simply practical.

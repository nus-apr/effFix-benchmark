#include <grub/i386/coreboot/console.h>
